import json
import os
import pymysql
import boto3
from botocore.exceptions import ClientError

# Retrieve database connection details from Lambda environment variables
DB_HOST = os.environ.get('DB_HOST')
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_NAME = os.environ.get('DB_NAME')
SECRET_NAME = os.environ.get('SECRET_NAME')
#sns_client = boto3.client('sns')
# def get_secret():

#     #secret_name = "db-password-2"
#     region_name = "us-east-1"

#     # Create a Secrets Manager client
#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )

#     try:
#         get_secret_value_response = client.get_secret_value(
#             SecretId=SECRET_NAME
#         )
#     except ClientError as e:
#         # For a list of exceptions thrown, see
#         # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
#         raise e

#     secret = get_secret_value_response['SecretString']
#     secret_dict = json.loads(secret)
#     db_pass = secret_dict['db-password']
#     return db_pass
# def get_db_endpoint():
#     ssm = boto3.client('ssm')

#     response = ssm.get_parameter(
#            Name='db-endpoint',  # Full path to your parameter
#            WithDecryption=True          # Only needed for SecureString
#     )
    
#     endpoint = response['Parameter']['Value']
#     return endpoint
def lambda_handler(event, context):
    """
    AWS Lambda handler function to retrieve user email details from a MySQL database.

    This function expects a 'userName' query parameter or path parameter.
    It connects to a MySQL database, queries the 'users' table for the
    given username, and returns the associated email ID.

    Args:
        event (dict): The event dictionary from API Gateway.
                      Expected to contain 'queryStringParameters' or 'pathParameters'
                      with a 'userName' key.
        context (object): The Lambda context object.

    Returns:
        dict: A dictionary representing the HTTP response, including
              statusCode, headers (with CORS), and a JSON body.
    """
    print(event)
    #sns_topic_arn="arn:aws:sns:us-east-1:808581944931:user-email-set-up"
    try:
        # Extract the username from the event.
        # API Gateway can pass parameters as query strings or path parameters.
        user_name = None
        if event.get('queryStringParameters') and 'userName' in event['queryStringParameters']:
            user_name = event['queryStringParameters']['userName']
        elif event.get('pathParameters') and 'userName' in event['pathParameters']:
            user_name = event['pathParameters']['userName']
        else:
            # If no username is provided in either, return a 400 Bad Request
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*' # Crucial for CORS
                },
                'body': json.dumps({'message': 'User name is required as a query parameter or path parameter.'})
            }

        # sns_message = f"New user request for the {user_name}"
        # sns_client.publish(
        #     TopicArn=sns_topic_arn,
        #     Message=sns_message,
        #     Subject=f"New User Request from {user_name}"
        # )

        # Basic validation for empty username
        if not user_name:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'message': 'User name cannot be empty.'})
            }

        # Establish a connection to the MySQL database
        # Using connect_timeout for better error handling in case of network issues
        # DB_PASSWORD = get_secret()
        # DB_HOST = get_db_endpoint()
        connection = pymysql.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            cursorclass=pymysql.cursors.DictCursor, # Returns rows as dictionaries (e.g., {'email_id': '...' })
            connect_timeout=10 # seconds
        )

        with connection.cursor() as cursor:
            # SQL query to select the email_id for a given user_name
            # Using parameterized query (%s) to prevent SQL injection
            sql = "SELECT email_id FROM users WHERE user_name = %s"
            cursor.execute(sql, (user_name)) # Pass parameters as a tuple
            result = cursor.fetchone() # Fetch a single row
            user_email = result['email_id']
            if result:
                insert_query = """
                    INSERT INTO user_requests ( user_name, user_email,timestamp)
                    VALUES ( %s, %s, NOW());    
                    """
                    #Create a unique ID for the request
                # request_id = "random"
                cursor.execute(insert_query, ( user_name, user_email))
        #       connection2.close() 
        connection.commit()
        connection.close() # Close the database connection

        if result:
        #     connection2 = pymysql.connect(
        #     host=DB_HOST,
        #     user=DB_USER,
        #     password=DB_PASSWORD,
        #     database=DB_NAME,
        #     cursorclass=pymysql.cursors.DictCursor, # Returns rows as dictionaries (e.g., {'email_id': '...' })
        #     connect_timeout=10 # seconds
        #   )
        #     user_email = result['email_id']
        #     # If a user is found, return their email ID
        #     with connection2.cursor() as cursor:
        #     # --- New Logic: Insert record into user_requests table ---
        #       insert_query = """
        #       INSERT INTO user_requests (id, user_name, user_email, request_details, timestamp)
        #       VALUES (%s, %s, %s, %s, NOW());
        #       """
        #     # Create a unique ID for the request
        #       request_id = "random"
        #       cursor.execute(insert_query, (request_id, user_name, user_email, "textMsg"))
        #       connection2.close() 
        #     # --- Existing Logic: Query for original purpose ---
        #     sql = "SELECT email_id FROM user_requests WHERE user_name = %s"
        #     cursor.execute(sql, (user_name))
        #     result2 = cursor.fetchone()
        #     print(result2," from user req")
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*' # Allow requests from any origin (for development)
                },
                'body': json.dumps({'userName': user_name, 'emailId': result['email_id']})
            }
            

           
        else:
            # If no user is found, return a 404 Not Found
            return {
                'statusCode': 404,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'message': f'User "{user_name}" not found.'})
            }

    except pymysql.Error as e:
        # Handle database-specific errors
        print(f"Database error: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'Database connection or query error.', 'error': str(e)})
        }
    except Exception as e:
        # Handle any other unexpected errors
        print(f"An unexpected error occurred: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'message': 'An unexpected error occurred.', 'error': str(e)})
        }
