import json
import os
import pymysql
import boto3
from botocore.exceptions import ClientError
from datetime import datetime, timedelta

# Initialize AWS clients
sns_client = boto3.client('sns')
# secrets_manager_client = boto3.client('secretsmanager')
# ssm_client = boto3.client('ssm')

# SNS Topic ARN - replace with your actual ARN
# Note: The ARN you provided in your code was "arn:aws:sns:us-east-1:808581944931:user-email-set-up".
# This code assumes you've created a dedicated topic for notifications as described in the steps.
# If your topic is different, update this ARN.
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')
# SECRET_NAME = os.environ.get('SECRET_NAME')
# def get_db_secret():

#     #secret_name = "db-password-2"
#     region_name = "us-east-1"

#     # Create a Secrets Manager client
#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )

#     try:
#         get_secret_value_response = client.get_secret_value(
#             SecretId=SECRET_NAME
#         )
#     except ClientError as e:
#         # For a list of exceptions thrown, see
#         # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
#         raise e

#     secret = get_secret_value_response['SecretString']
#     secret_dict = json.loads(secret)
#     db_pass = secret_dict['db-password']
#     return db_pass
# def get_db_endpoint():
#     ssm = boto3.client('ssm')

#     response = ssm.get_parameter(
#            Name='db-endpoint',  # Full path to your parameter
#            WithDecryption=True          # Only needed for SecureString
#     )
    
#     endpoint = response['Parameter']['Value']
#     return endpoint

def lambda_handler(event, context):
    """
    AWS Lambda handler function for the hourly user request report.

    This function is triggered by an EventBridge rule. It queries an RDS
    MySQL database for all user requests from the last hour and sends
    a summary report via SNS.
    """
    #print("Received EventBridge event:", json.dumps(event))

    # Retrieve database connection details from environment variables
    # The SECRET_NAME and DB_ENDPOINT_PARAM_NAME should be set in your Lambda function's
    # environment variables.
    DB_USER = os.environ.get('DB_USER')
    DB_NAME = os.environ.get('DB_NAME')
   # DB_HOST = get_db_endpoint()
    DB_HOST = os.environ.get('DB_HOST')  # Assuming DB_HOST is set in environment variables
    #SECRET_NAME = os.environ.get('SECRET_NAME')
    #DB_ENDPOINT_PARAM_NAME = os.environ.get('DB_ENDPOINT_PARAM_NAME')

    # if not all([DB_USER, DB_NAME, SECRET_NAME, DB_ENDPOINT_PARAM_NAME]):
    #     error_msg = "Missing required environment variables for database connection."
    #     print(error_msg)
    #     return {
    #         'statusCode': 500,
    #         'body': json.dumps({'message': error_msg})
    #     }

    try:
        # Get DB credentials and endpoint
        # DB_PASSWORD = get_db_secret()
  
        DB_PASSWORD = os.environ.get('DB_PASSWORD')  # Assuming DB_PASSWORD is set in environment variables
        # Calculate the time range for the last hour in UTC
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=1)
        
        # Connect to the MySQL database
        connection = pymysql.connect(
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASSWORD,
            database=DB_NAME,
            cursorclass=pymysql.cursors.DictCursor
        )

        with connection.cursor() as cursor:
            # Query for all requests in the last hour
            query = """
            SELECT user_name, user_email
            FROM user_requests
            WHERE timestamp >= %s AND timestamp <= %s and message="new user";
            """
            cursor.execute(query, (start_time, end_time))
            records = cursor.fetchall()
        
        connection.close()
        
        # Format the summary message
        if not records:
            summary_message = "No new user requests were received in the last hour."
            subject = "Hourly User Request Report: No New Requests"
        else:
            total_requests = len(records)
            summary_list = "\n".join([
                f"- User: {record['user_name']} ({record['user_email']})" for record in records
            ])
            summary_message = (
                f"Hourly Summary: {total_requests} new user requests received.\n"
                f"----------------------------------------\n"
                f"{summary_list}\n"
                f"----------------------------------------"
            )
            subject = f"Hourly User Request Report: {total_requests} New Requests"
            
        # Publish the summary to the SNS topic
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=summary_message,
            Subject=subject
        )
        print("Hourly summary published successfully.")
        
        return {
            'statusCode': 200,
            'body': json.dumps('Hourly report generation completed.')
        }
    
    except Exception as e:
        print(f"Error generating hourly report: {e}")
        # Send an error notification if the report fails
        sns_client.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=f"An error occurred while generating the hourly report: {e}",
            Subject="ERROR: Hourly User Request Report"
        )
        
        return {
            'statusCode': 500,
            'body': json.dumps('An error occurred during report generation.')
        }

